SELECT A.total_duration,
A.watching_strength,
(A.total_duration/A.watching_strength) AS av_reg_watch
FROM
(SELECT COUNT(first_date_watched) AS watching_strength,
-SUM(date_diff_reg_watch) AS total_duration      /* here -SUM is used because in the result_data_set date_diff_reg_watch returns a negative value; can be optimized by modifying DATEDIFF used in it */
FROM result_data_set) AS A