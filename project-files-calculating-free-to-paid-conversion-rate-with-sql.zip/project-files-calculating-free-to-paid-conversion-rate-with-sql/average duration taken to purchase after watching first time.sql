SELECT A.total_duration,
A.purchase_strength,
(A.total_duration/A.purchase_strength) AS av_watch_purch
FROM
(SELECT COUNT(first_date_purchased) AS purchase_strength,
SUM(date_diff_watch_purch) AS total_duration
FROM result_data_set) AS A;
