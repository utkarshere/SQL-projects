SELECT A.purchasing_strength, 
	   A.watching_strength,
       (A.purchasing_strength/A.watching_strength)*100 AS conversion_rate
FROM
(
SELECT COUNT(student_id) AS purchasing_strength, 
(SELECT COUNT(student_id) FROM result_data_set
WHERE first_date_watched IS NOT NULL) AS watching_strength
FROM result_data_set
WHERE date_diff_watch_purch IS NOT NULL ) AS A
