CREATE TABLE result_data_set(

student_id INT NOT NULL,

date_registered DATE,

first_date_watched DATE,

first_date_purchased DATE,

date_diff_reg_watch INT,

date_diff_watch_purch INT);

INSERT INTO result_data_set
(
SELECT
r.student_id,

r.date_registered,

MIN(e.date_watched) AS first_date_watched,

COALESCE(MIN(p.date_purchased),

NULL) AS first_date_purchased,

DATEDIFF(date_registered, MIN(date_watched)) AS date_diff_reg_watch,

COALESCE(DATEDIFF(MIN(date_purchased), MIN(date_watched)), NULL) AS date_diff_watch_purch

FROM

student_info r

JOIN

student_engagement e ON r.student_id = e.student_id

LEFT JOIN

student_purchases p ON e.student_id = p.student_id

GROUP BY r.student_id

HAVING date_diff_watch_purch >=0 IS NOT FALSE

ORDER BY r.student_id)
;

SELECT * FROM result_data_set